#ifndef COMMANDS_COMMANDS_H
#define COMMANDS_COMMANDS_H

#include "../Particle/particle.h"

/**
 * Command execution for single particle
 * @param particle
 */
void execCommand(Particle *particle);

#endif //COMMANDS_COMMANDS_H
